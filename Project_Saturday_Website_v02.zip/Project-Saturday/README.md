# Project Saturday — Week 11 League Hub

A mobile-first, self-contained website prototype for the 2027 online dynasty. Open `index.html` in a browser. No installation or accounts required for this local version.

## Included
- Home page, Week 11 featured games, conference leaders, and top-four Heisman watch
- ACC, American, and Big 12 standings from commissioner screenshots
- Full Week 11 schedule including two completed games
- Team profiles with known statistics (unknown statistics intentionally omitted)
- Press conference draft form (answers saved only in the current browser's local storage)
- Screenshot preview intake (images never leave the device)
- Commissioner overview and integration roadmap

## Accuracy and limitations
- Houston is **7–2 overall, 6–1 Big 12**.
- Baylor is CPU-controlled.
- ACC featured matchup is UCF @ Syracuse.
- Official PP BCS Week 11 rankings are not available, so no rankings are fabricated.
- This is a static prototype: no EA integration, cloud storage, logins, automated screenshot parsing, or cross-device sharing yet.

## Next steps
Host the static website; add a hosted database, coach authentication, verified data import/review, and official ranking formula. Investigate EA access separately.
